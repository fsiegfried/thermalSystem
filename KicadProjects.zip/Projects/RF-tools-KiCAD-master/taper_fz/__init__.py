from .taper_plugin import TaperPlugin
TaperPlugin().register()
