from .trace_length import SelectedTracesLenght
SelectedTracesLenght().register()
